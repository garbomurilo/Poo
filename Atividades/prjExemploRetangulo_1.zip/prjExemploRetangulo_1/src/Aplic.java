/**
 *
 * @author Yuki
 */
public class Aplic {
    public static void main(String[] args) {
        Retangulo objRet; // definição de ponteiro
        
        objRet = new Retangulo(); // instanciação do objeto na memória
        
        objRet.setAltura(5.0);
        objRet.setBase(8.0);
        
        System.out.println("Medida da altura do retângulo: " + 
                            objRet.getAltura());
        System.out.println("Medida da bse do retângulo: " +
                            objRet.getBase());
        System.out.println("Medida da área do retângulo: " +
                            objRet.calcArea());
        System.out.println("Medida do perímetro do retângulo: " +
                            objRet.calcPerimetro());
        System.out.println("Medida da diagonal do retângulo: " +
                            objRet.calcDiagonal());
    }
    
}
